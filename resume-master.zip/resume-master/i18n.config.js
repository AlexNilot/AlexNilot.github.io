module.exports = {
  exclude: ['**/i18n/**', '**/data/**'],
};
